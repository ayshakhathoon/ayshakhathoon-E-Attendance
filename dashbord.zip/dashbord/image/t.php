<?php
include 'db_con.php';
if(isset($_POST['register'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $class_id = $_POST['class_id'];
    $dob = $_POST['dob'];
    $qual =  $_POST['qual'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
        $user_check = "SELECT `type_id` FROM `tbl_usertype` WHERE `type_name` = 'teacher'";
        $user_check_rslt = mysqli_query($conn,$user_check);
        while($row = mysqli_fetch_array($user_check_rslt)){
            //echo $row['type_id'];
        $type = $row['type_id'];
        $user_reg = "INSERT INTO `tbl_teacher`(`fname`, `lname`, `dob`, `qualification`, `gender`, `address`, `email`, `phone`)
         VALUES ('$fname','$lname','$dob','$qual','$gender','$address','$email','$phone')";
        $user_reg_query = mysqli_query($conn,$user_reg);
        
        $last_id = mysqli_insert_id($conn);
        if($user_reg_query){
          $reg = "INSERT INTO `tbl_login`(`adn_no`, `password`, `type_id`) VALUES ('$last_id','$password','$type')";
          $reg_query = mysqli_query($conn,$reg);
            echo'<script> alert ("Account created '.$last_id.'");</script>';
            echo'<script>window.location.href="sign.php";</script>'; 
        }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Login</title>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Rubik:400,700"
    />
    <link rel="stylesheet" href="./style.css" />
  </head>
  <body>
  <script>
                 function validate()
                {
					var f=document.getElementById("fname").value;
					var s=/^[a-zA-Z]+$/;
						   if(f=="")
                {
                    document.getElementById('fn').style.display = "block";

                    document.getElementById('fn').innerHTML="**Please Enter  First Name";
                    return false;
                }
					if(f!="" && s.test(f)==false){

						document.getElementById('fn').style.display = "block";
						document.getElementById('fn').innerHTML = "Invalid First Name";
						return false;
					}
					else{
						document.getElementById('fn').style.display = "none";
          
					}
          var l=document.getElementById("lname").value;
          if(l=="")
                {
                    document.getElementById('ln').style.display = "block";

                    document.getElementById('ln').innerHTML="**Please Enter  Last Name";
                    return false;
                }
					if(l!="" && s.test(l)==false){

						document.getElementById('ln').style.display = "block";
						document.getElementById('ln').innerHTML = "Invalid Last Name";
						return false;
					}
					else{
						document.getElementById('ln').style.display = "none";
					}



          var o=document.getElementById("dob").value;
          if(o=="")
                {
                    document.getElementById('bh').style.display = "block";

                    document.getElementById('bh').innerHTML="**Please Enter  Date of birth";
                    return false;
                }
	
					else{
						document.getElementById('bh').style.display = "none";
					}



          var n=document.getElementById("qtn").value;
          if(n=="")
                {
                    document.getElementById('qn').style.display = "block";

                    document.getElementById('qn').innerHTML="**Please Enter  Qualification";
                    return false;
                }
	
					else{
						document.getElementById('qn').style.display = "none";
					}



          var m=document.getElementById("gender").value;
          if(m=="")
                {
                    document.getElementById('gen').style.display = "block";

                    document.getElementById('gen').innerHTML="**Please Enter  Gender";
                    return false;
                }
	
					else{
						document.getElementById('gen').style.display = "none";
					}






          var k=document.getElementById("address").value;
          if(k=="")
                {
                    document.getElementById('ad').style.display = "block";

                    document.getElementById('ad').innerHTML="**Please Enter  Address";
                    return false;
                }
	
					else{
						document.getElementById('ad').style.display = "none";
					}



          var a=document.getElementById("email").value;
					var st=/^[\w\+\'\.-]+@[\w\'\.-]+\.[a-zA-Z]{2,}$/;
					if(a=="")
                {
                    document.getElementById('el').style.display = "block";

                    document.getElementById('el').innerHTML="**Please Enter  Email";
                    return false;
                }
					if(a!="" && st.test(a)==false){

						document.getElementById('el').style.display = "block";
						document.getElementById('el').innerHTML = "Invalid Email id";
						return false;
					}
					else{
						document.getElementById('el').style.display = "none";

					}
          var ph = document.getElementById("tel").value;
					var expr = /^[6-9]\d{9}$/;
                    if(ph=="")
                {
                    document.getElementById('pe').style.display = "block";

                    document.getElementById('pe').innerHTML="**Please Enter  Phone Number";
                    return false;
                }
					if(ph!="" && expr.test(ph)==false){
						document.getElementById('pe').style.display = "block";
						document.getElementById('pe').innerHTML = "Invalid Phone number";
						return false;
								}
								else{
						document.getElementById('pe').style.display = "none";

					}
           var d=document.getElementById('password').value;

                     var e=document.getElementById('cpassword').value;
                   if(d=="")
                {
                    document.getElementById('pss').style.display = "block";

                  document.getElementById('pss').innerHTML="**please enter  Password";
                    return false;
                }
                else{
						document.getElementById('pss').style.display = "none";
					}
                if(e=="")
                {
                    document.getElementById('cpass').style.display = "block";

                    document.getElementById('cpss').innerHTML="**please enter Confirm Password";
                    return false;
                }

                if(d!=e)
                {
                    document.getElementById('cpss').style.display = "block";

                    document.getElementById('cpss').innerHTML="**Incorrect Password";
                    return false;
                }
                        else
                          {
                          	document.getElementById('cpss').style.display = "none";

                    return true;
                }


        }
      </script>
    <!-- partial:index.partial.html -->
    <div class="login-form">
      <form action="" method="post" onsubmit="return validate();">
        <h1>Teacher Register</h1>
        <div class="content">
          <div class="input-field">
            <input type="text" name="fname" placeholder="Enter first name" id="fname"  title="Name must be alphabets" onblur="return validate()" onKeyUp="return validate()"/>
            <span id="fn" style="color: red;"></span>

          </div>
          <div class="input-field">
            <input type="text" name="lname" id="lname" placeholder="Enter last name"  title="Name must be alphabets" onblur="return validate()" onKeyUp="return validate()"/>
            <span id="ln" style="color: red;"></span>

          </div>
          <div class="input-field">
            <input type="date" name="dob" placeholder="Enter date of birth" id="dob" onblur="return validate()" onKeyUp="return validate()" />
            <span id="bh" style="color: red;"></span>

          </div>
          <div class="input-field">
            <input type="text" name="class_id" placeholder="Enter the qualification" id="qtn" onblur="return validate()" onKeyUp="return validate()" />
            <span id="qn" style="color: red;"></span>

          </div>
          <div class="input-field">
            <input type="text" name="gender" placeholder="Enter gender"   title="Name must be alphabets" id="gender" onblur="return validate()" onKeyUp="return validate()"/>
            <span id="gen" style="color: red;"></span>

          </div>
          <div class="input-field">
            <input type="text" name="address" placeholder="Enter address" id="address" onblur="return validate()" onKeyUp="return validate()"/>
            <span id="ad" style="color: red;"></span>

          </div>
          <div class="input-field">
            <input type="text" name="email" placeholder="Enter mail" id="email" onblur="return validate()" onKeyUp="return validate()"/>
            <span id="el" style="color: red;"></span>

          </div> 
          <div class="input-field">
            <input type="text" name="phone" placeholder="Enter phone" id="tel"   title="Please enter a valid phone number" onblur="return validate()" onKeyUp="return validate()"  minlength="10" maxlength="10"/>
            <span id="pe" style="color: red;"></span>

          </div>
          <div class="input-field">
            <input type="password" name="password" id="password" placeholder="Password"/>
              <span id="pss" style="color: red;"></span>
              
              <style>
                                                 /* The message box is shown when the user clicks on the password field */
                                                    #message {
                                                    display:none;
                                                    background:#fff;
                                                    color: #000;
                                                    position: relative;
                                                    padding: 20px;
                                                    margin-top: 10px;
                                                    }
                                                                        #message p {
                                                    padding: 1px 35px;
                                                    font-size: 14px;
                                                    }
                                                    /* Add a green text color and a checkmark when the requirements are right */
                                                    .valid {
                                                    color: green;
                                                    }

                                                    .valid:before {
                                                    position: relative;
                                                    left: -25px;
                                                    content: "✔";
                                                    }

                                                    /* Add a red text color and an "x" when the requirements are wrong */
                                                    .invalid {
                                                    color: red;
                                                    }

                                                    .invalid:before {
                                                    position: relative;
                                                    left: -25px;
                                                    content: "✖";
                                                    }
                                                    </style>
                                                <div id="message">
<!--                                                    <h4 style="color:rgb(249, 164, 61) ;">Password must contain the following:</h4>-->
                                                        <p id="letter" class="invalid">A lowercase letter</p>
                                                        <p id="capital" class="invalid">A capital (uppercase) letter</p>
                                                        <p id="number" class="invalid">A number</p>
                                                        <p id="length" class="invalid">Minimum 8 characters</b></p>
                                                     </div>
                                                <script>
                                        var myInput = document.getElementById("password");
                                        var letter = document.getElementById("letter");
                                        var capital = document.getElementById("capital");
                                        var number = document.getElementById("number");
                                        var length = document.getElementById("length");
                                        myInput.onfocus = function() {
                                        document.getElementById("message").style.display = "block";
                                        }
                                        myInput.onblur = function() {
                                        document.getElementById("message").style.display = "none";
                                        }
                                        // When the user starts to type something inside the password field
                                        myInput.onkeyup = function() {
                                        // Validate lowercase letters
                                        var lowerCaseLetters = /[a-z]/g;
                                        if(myInput.value.match(lowerCaseLetters)) {
                                            letter.classList.remove("invalid");
                                            letter.classList.add("valid");
                                        } else {
                                            letter.classList.remove("valid");
                                            letter.classList.add("invalid");
                                        }

                                        // Validate capital letters
                                        var upperCaseLetters = /[A-Z]/g;
                                        if(myInput.value.match(upperCaseLetters)) {
                                            capital.classList.remove("invalid");
                                            capital.classList.add("valid");
                                        } else {
                                            capital.classList.remove("valid");
                                            capital.classList.add("invalid");
                                        }

                                        // Validate numbers
                                        var numbers = /[0-9]/g;
                                        if(myInput.value.match(numbers)) {
                                            number.classList.remove("invalid");
                                            number.classList.add("valid");
                                        } else {
                                            number.classList.remove("valid");
                                            number.classList.add("invalid");
                                        }

                                        // Validate length
                                        if(myInput.value.length >= 8) {
                                            length.classList.remove("invalid");
                                            length.classList.add("valid");
                                        } else {
                                            length.classList.remove("valid");
                                            length.classList.add("invalid");
                                        }
                                        }
                                    </script>
      

          </div>
          <div class="input-field">
            <input type="password" name="cpassword" placeholder="confirm password"  id="cpassword"  onblur="return validate()" onKeyUp="return validate()"/>
            <span id="cpss" style="color: red;"></span>

          </div>

        </div>
        <div class="action">
        <button onclick()="window.location.href=sign.php">Sign in</button>
          <button type="submit" name="register">Register</button>
         
        </div>
      </form>
    </div>
    <!-- partial -->
    <!-- <script  src="./script.js"></script> -->
  </body>
</html>
<?php
include "db_con.php";
session_start();
session_unset();
?><html>
<head>
    <title> E-ATTENDANCE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login_bg">
        <nav>
            <div class="logo">E ATTENDANCE</div>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="#">ABOUT</a></li>
                <li><a href="#">CONTACT US</a></li>
                <li><a href="sign.php">LOGIN</a></li>
                </a></li>
            </ul>
        </nav>
        <section>
        </section>
</body>
        <section class="abc">
            <h2 id="about">About</h2>
            <div>
                <section>
              <p>  The Student Attendance Management System is a simple PHP/MySQL project that will help faculty manage his/her student's attendance records for each class
                <p> and subject in a certain school. The system stores the related data or information that are needed to generate the class attendance and also those data 
             <p>that are needed to organized the students. This system allows the faculties to store the attendance record of his/her student each subject and by simply 
                <p>selecting the class per subject for checking the attendance, the list of a student under the selected class per subject will be displayed automatically 
                    <p>along with the checkboxes for identifying if the student is present, late, or absent on the selected date of the class.
</section>
            </div>
        </section>
</section>       
 </body>
</html>
<html>

    <head>
        <title>Application Form</title>
    </head>
    <body>
        <h1 style=text-align:center>Leave Application</h1>
        <form>
            <table>
                <tr>
                    <td>
                        Name:
                    </td>
                    <td>
                        <input type="text" placeholder="Name" name="">
                    </td>
                </tr>
                <tr>
                    <td>
                        Date:
                    </td>
                    <td>
                        <input type="date" placeholder="01/01/11">
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Reason:
                    </td>
                    <td>
                        <input type="text" placeholder="Reason">
                    </td>
                </tr>
                <td>
                    <input type="submit" value="Submit">
                    <input type="reset" value="Reset">
                </td>
            </tr>
            </table>
        </form>
        </body>
</html>
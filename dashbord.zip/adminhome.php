<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Admin Dashboard</title>
        <link rel="stylesheet" type="text/css" href="admin.css">
    </head>
    <body>


<header class="header">
<a href=" ">Admin Dashboard</a>
<div>
    <a href="">logout</a>
</div>
</header>
<aside>
<ul>
    <li><a href="">register</a>
    <label for="register"></label>
<select name="color" id="color">
	
	<option value="red">student<a href="reg_s.php"></a></option>
	<option value="green">teacher</option>
	<option value="blue">parents</option>
</select></li>
    <li><a href="">add</a></li>
    <li><a href="">view</a></li>
    <li><a href="">attendance reports</a></li>




</ul>


</aside>
</body>
</html>